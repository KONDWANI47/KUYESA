export function PlaylistsSection() {
  return (
    <div className="bg-gradient-to-r from-blue-800 to-purple-800 text-white rounded-lg p-8 text-center">
      <h2 className="text-3xl font-bold mb-4">Welcome to Cupicsart Beats and Samples</h2>
      <p className="text-xl mb-6">
        Discover curated playlists featuring the best beats and samples from Cupicsart and other artists.
      </p>
      <p className="text-lg">Sign in to create your own playlists and save your favorite tracks.</p>
    </div>
  )
}
