"use client"

import { useState, useEffect } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Card } from "@/components/ui/card"
import { Play, Pause, Volume2, VolumeX } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"

type Audio = {
  id: string
  title: string
  artist: string
  genre: string
  fileUrl: string
  createdAt: string
}

export function AudioList() {
  const [audioList, setAudioList] = useState<Audio[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [currentAudio, setCurrentAudio] = useState<Audio | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(0.5)
  const [isMuted, setIsMuted] = useState(false)
  const { toast } = useToast()

  // Mock audio data for demonstration
  useEffect(() => {
    // In a real app, fetch from your API
    const mockAudioList: Audio[] = [
      {
        id: "1",
        title: "Africa Trap Beat",
        artist: "cupicsart",
        genre: "Trap",
        fileUrl: "https://example.com/audio1.mp3",
        createdAt: new Date().toISOString(),
      },
      {
        id: "2",
        title: "Story Telling Type Beat",
        artist: "Cupicsart",
        genre: "Hip Hop",
        fileUrl: "https://example.com/audio2.mp3",
        createdAt: new Date().toISOString(),
      },
      {
        id: "3",
        title: "Smooth Jazz Sample",
        artist: "JazzMaster",
        genre: "Jazz",
        fileUrl: "https://example.com/audio3.mp3",
        createdAt: new Date().toISOString(),
      },
    ]

    setAudioList(mockAudioList)
    setIsLoading(false)
  }, [])

  const togglePlay = (audio: Audio) => {
    if (currentAudio?.id === audio.id) {
      setIsPlaying(!isPlaying)
    } else {
      setCurrentAudio(audio)
      setIsPlaying(true)
    }
  }

  const toggleMute = () => {
    setIsMuted(!isMuted)
  }

  const handleVolumeChange = (value: number[]) => {
    setVolume(value[0])
    if (value[0] > 0 && isMuted) {
      setIsMuted(false)
    }
  }

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <p>Loading audio tracks...</p>
      </div>
    )
  }

  if (audioList.length === 0) {
    return (
      <div className="text-center py-8">
        <p>No audio tracks found. Upload some music to get started!</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold mb-4">Audio Tracks</h2>

      {audioList.map((audio) => (
        <Card key={audio.id} className="overflow-hidden">
          <div className="flex items-center p-4">
            <Button
              variant="ghost"
              size="icon"
              className="mr-4"
              onClick={() => togglePlay(audio)}
              aria-label={isPlaying && currentAudio?.id === audio.id ? "Pause" : "Play"}
            >
              {isPlaying && currentAudio?.id === audio.id ? (
                <Pause className="h-6 w-6" />
              ) : (
                <Play className="h-6 w-6" />
              )}
            </Button>

            <div className="flex-1">
              <h3 className="text-lg font-semibold">{audio.title}</h3>
              <p className="text-sm text-gray-500">
                {audio.artist} • {audio.genre}
              </p>
            </div>

            {currentAudio?.id === audio.id && (
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" onClick={toggleMute} aria-label={isMuted ? "Unmute" : "Mute"}>
                  {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
                </Button>
                <div className="w-24">
                  <Slider
                    value={[isMuted ? 0 : volume]}
                    min={0}
                    max={1}
                    step={0.01}
                    onValueChange={handleVolumeChange}
                    aria-label="Volume"
                  />
                </div>
              </div>
            )}
          </div>
        </Card>
      ))}
    </div>
  )
}
