import Image from "next/image"

type Artist = {
  id: string
  name: string
  imageUrl: string
  linkUrl: string
  linkText: string
}

const artists: Artist[] = [
  {
    id: "1",
    name: "cupicsart",
    imageUrl: "/placeholder.svg?height=200&width=200",
    linkUrl: "https://cupicsartmuzik.bandcamp.com/track/africa-trap-type-of-beat-prod-by-cupicsart-muzik",
    linkText: "Africa trap by cupicsart",
  },
  {
    id: "2",
    name: "Jaguar",
    imageUrl: "/placeholder.svg?height=200&width=200",
    linkUrl: "https://jaguarpawmw.bandcamp.com/album/jaguar-paw-volume-i-afro",
    linkText: "Jaguar Paw Volume I (Afro)",
  },
  {
    id: "3",
    name: "Cupicsart",
    imageUrl: "/placeholder.svg?height=200&width=200",
    linkUrl: "https://audiomack.com/cupicsart-1/song/67d18b1ca7faa",
    linkText: "Story telling type of beat",
  },
  {
    id: "4",
    name: "CARBON MW",
    imageUrl: "/placeholder.svg?height=200&width=200",
    linkUrl: "https://www.youtube.com/watch?v=gXLqGCbhqUY",
    linkText: "ADZALIRA BY Carbon MW",
  },
]

export function ArtistsGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {artists.map((artist) => (
        <div
          key={artist.id}
          className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
        >
          <div className="p-4">
            <h3 className="text-xl font-semibold mb-2">{artist.name}</h3>
            <div className="relative h-48 w-full mb-4">
              <Image
                src={artist.imageUrl || "/placeholder.svg"}
                alt={artist.name}
                fill
                className="object-cover rounded"
              />
            </div>
            <a
              href={artist.linkUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              {artist.linkText}
            </a>
          </div>
        </div>
      ))}
    </div>
  )
}
