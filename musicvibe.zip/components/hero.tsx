import Link from "next/link"

export function Hero() {
  return (
    <section className="relative py-20 px-4 text-center text-white">
      <div
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage: "url('/placeholder.svg?height=600&width=1200')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      />
      <div className="absolute inset-0 bg-black bg-opacity-60 z-10"></div>

      <div className="relative z-20 max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Discover Your Music Vibe</h1>
        <p className="text-xl mb-8">Explore millions of songs, create playlists, and connect with artists.</p>
        <Link
          href="/playlists"
          className="inline-block bg-yellow-500 hover:bg-yellow-600 text-blue-900 font-bold py-3 px-8 rounded-md transition-colors"
        >
          Get Started
        </Link>

        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-4">Other Artists YouTube Channels</h2>
          <Link
            href="https://www.youtube.com/watch?v=Im37NDTRmS4&list=RDMMIm37NDTRmS4&start_radio=1"
            className="text-yellow-400 hover:text-yellow-300 underline transition-colors"
          >
            Popular YouTubers
          </Link>
        </div>
      </div>
    </section>
  )
}
