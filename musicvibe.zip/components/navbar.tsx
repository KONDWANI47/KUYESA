"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { SearchBar } from "./search-bar"
import { Button } from "@/components/ui/button"
import { useSession, signOut } from "next-auth/react"
import { Menu } from "lucide-react"

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()
  const { data: session } = useSession()

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  return (
    <nav className="bg-gradient-to-r from-blue-900 to-blue-600 text-white sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <div className="relative h-10 w-10 mr-2">
                <Image
                  src="/placeholder.svg?height=40&width=40"
                  alt="MusicVibe Logo"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
              <span className="text-xl font-bold">MusicVibe</span>
            </Link>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-white"
            onClick={toggleMenu}
            aria-label="Toggle menu"
            aria-expanded={isMenuOpen}
          >
            <Menu className="h-6 w-6" />
          </Button>

          <div
            className={`md:flex items-center gap-6 ${isMenuOpen ? "flex flex-col absolute top-16 left-0 right-0 bg-blue-800 p-4 shadow-md" : "hidden"} md:static md:flex-row md:bg-transparent md:p-0 md:shadow-none`}
          >
            <div className={`flex ${isMenuOpen ? "flex-col w-full" : "flex-row"} gap-4 md:gap-6`}>
              <NavLink href="/" active={pathname === "/"}>
                Home
              </NavLink>
              <NavLink href="/genres" active={pathname === "/genres"}>
                Genres
              </NavLink>
              <NavLink href="/artists" active={pathname === "/artists"}>
                Artists
              </NavLink>
              <NavLink href="/playlists" active={pathname === "/playlists"}>
                Playlists
              </NavLink>
              {session && (
                <NavLink href="/audio" active={pathname === "/audio"}>
                  Audio
                </NavLink>
              )}
              <NavLink href="/contact" active={pathname === "/contact"}>
                Contact
              </NavLink>
            </div>

            <div className={`mt-4 md:mt-0 ${isMenuOpen ? "w-full" : ""}`}>
              <SearchBar />
            </div>

            {session ? (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => signOut()}
                className={`mt-4 md:mt-0 ${isMenuOpen ? "w-full" : ""}`}
              >
                Logout
              </Button>
            ) : null}
          </div>
        </div>
      </div>
    </nav>
  )
}

function NavLink({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className={`font-medium hover:text-yellow-300 transition-colors ${active ? "text-yellow-300" : "text-white"}`}
    >
      {children}
    </Link>
  )
}
