import Image from "next/image"

type Genre = {
  id: string
  name: string
  imageUrl: string
  linkUrl: string
  linkText: string
}

const genres: Genre[] = [
  {
    id: "1",
    name: "SUDZIWA",
    imageUrl: "/placeholder.svg?height=200&width=200",
    linkUrl: "https://youtu.be/b7rExd72F00?si=JRkNjMVPZIm13sl3",
    linkText: "SUDZIWA BY PHYZIX FT Quest",
  },
  {
    id: "2",
    name: "WADONGO",
    imageUrl: "/placeholder.svg?height=200&width=200",
    linkUrl: "https://www.youtube.com/watch?v=KiNKnZMM87U",
    linkText: "wadongo by Jay Jay ft MAN-CHI",
  },
  {
    id: "3",
    name: "misozi",
    imageUrl: "/placeholder.svg?height=200&width=200",
    linkUrl: "https://www.youtube.com/watch?v=Bp8IVbWurtI&list=RDMM&start_radio=1&rv=KiNKnZMM87U",
    linkText: "Misozi by Waxy Kay",
  },
  {
    id: "4",
    name: "Cupicsart",
    imageUrl: "/placeholder.svg?height=200&width=200",
    linkUrl: "https://audiomack.com/cupicsart-1/song/67d18b1ca7faa",
    linkText: "Story telling type of beat",
  },
]

export function GenresGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {genres.map((genre) => (
        <div key={genre.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <div className="p-4">
            <h3 className="text-xl font-semibold mb-2">{genre.name}</h3>
            <div className="relative h-48 w-full mb-4">
              <Image
                src={genre.imageUrl || "/placeholder.svg"}
                alt={genre.name}
                fill
                className="object-cover rounded"
              />
            </div>
            <a
              href={genre.linkUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-800 transition-colors"
            >
              {genre.linkText}
            </a>
          </div>
        </div>
      ))}
    </div>
  )
}
