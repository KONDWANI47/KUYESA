import Link from "next/link"

export function Footer() {
  return (
    <footer className="bg-blue-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="hover:text-yellow-300 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-yellow-300 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-yellow-300 transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-yellow-300 transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-4">Genres</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/genres" className="hover:text-yellow-300 transition-colors">
                  Trap
                </Link>
              </li>
              <li>
                <Link href="/genres" className="hover:text-yellow-300 transition-colors">
                  Hip Hop
                </Link>
              </li>
              <li>
                <Link href="/genres" className="hover:text-yellow-300 transition-colors">
                  Jazz
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-4">Contact</h3>
            <p className="mb-2">
              Email:{" "}
              <a href="mailto:cupicsart@gmail.com" className="hover:text-yellow-300 transition-colors">
                cupicsart@gmail.com
              </a>
            </p>
            <p className="mb-4">
              Phone:{" "}
              <a href="tel:+265992260985" className="hover:text-yellow-300 transition-colors">
                +265 992 260 985
              </a>
            </p>

            <div className="flex flex-wrap gap-4 mt-4">
              <a
                href="https://youtu.be/dPoW98UNYSg?si=laNOa90lsYRnj676"
                className="hover:text-yellow-300 transition-colors"
                aria-label="YouTube"
              >
                YouTube
              </a>
              <a href="https://facebook.com" className="hover:text-yellow-300 transition-colors" aria-label="Facebook">
                Facebook
              </a>
              <a href="https://twitter.com" className="hover:text-yellow-300 transition-colors" aria-label="Twitter">
                Twitter
              </a>
              <a
                href="https://instagram.com"
                className="hover:text-yellow-300 transition-colors"
                aria-label="Instagram"
              >
                Instagram
              </a>
              <a
                href="https://www.tiktok.com/tiktokstudio"
                className="hover:text-yellow-300 transition-colors"
                aria-label="TikTok"
              >
                TikTok
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-blue-800 text-center">
          <p>&copy; {new Date().getFullYear()} MusicVibe. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
