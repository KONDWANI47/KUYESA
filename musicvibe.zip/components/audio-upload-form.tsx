"use client"

import { useState } from "react"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { useToast } from "@/components/ui/use-toast"
import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"

const formSchema = z.object({
  title: z.string().min(3, { message: "Title must be at least 3 characters" }),
  artist: z.string().min(2, { message: "Artist name must be at least 2 characters" }),
  genre: z.string().min(2, { message: "Please select a genre" }),
  file: z
    .instanceof(File, { message: "Please select an audio file" })
    .refine((file) => file.size <= 10 * 1024 * 1024, "File size must be less than 10MB")
    .refine(
      (file) => ["audio/mpeg", "audio/wav", "audio/mp3"].includes(file.type),
      "Only MP3 or WAV files are allowed",
    ),
})

type FormValues = z.infer<typeof formSchema>

export function AudioUploadForm() {
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const router = useRouter()

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      artist: "",
      genre: "",
    },
  })

  async function onSubmit(data: FormValues) {
    setIsLoading(true)

    try {
      // In a real app, you would upload the file to a storage service
      // and get back a URL to store in your database

      // Mock file upload - in a real app, replace with actual upload logic
      const mockFileUrl = `https://example.com/uploads/${Date.now()}-${data.file.name}`

      // Save the audio metadata to the database
      const response = await fetch("/api/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: data.title,
          artist: data.artist,
          genre: data.genre,
          fileUrl: mockFileUrl,
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        toast({
          title: "Upload Failed",
          description: result.error || "Failed to upload audio. Please try again.",
          variant: "destructive",
        })
        return
      }

      toast({
        title: "Upload Successful",
        description: "Your audio has been uploaded successfully!",
      })

      form.reset()
      router.refresh()
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="mb-8">
      <CardHeader>
        <CardTitle>Upload Audio</CardTitle>
        <CardDescription>Share your music with the MusicVibe community</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Audio title" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="artist"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Artist</FormLabel>
                  <FormControl>
                    <Input placeholder="Artist name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="genre"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Genre</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a genre" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="trap">Trap</SelectItem>
                      <SelectItem value="hip-hop">Hip Hop</SelectItem>
                      <SelectItem value="jazz">Jazz</SelectItem>
                      <SelectItem value="afrobeat">Afrobeat</SelectItem>
                      <SelectItem value="rnb">R&B</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="file"
              render={({ field: { value, onChange, ...fieldProps } }) => (
                <FormItem>
                  <FormLabel>Audio File (MP3, WAV, max 10MB)</FormLabel>
                  <FormControl>
                    <Input
                      type="file"
                      accept="audio/mp3,audio/wav,audio/mpeg"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          onChange(file)
                        }
                      }}
                      {...fieldProps}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? "Uploading..." : "Upload Audio"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  )
}
