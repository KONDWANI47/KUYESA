"use client"

import { useState, useEffect } from "react"
import { useToast } from "@/components/ui/use-toast"
import { Card } from "@/components/ui/card"
import { Play } from "lucide-react"
import { Button } from "@/components/ui/button"

type SearchResult = {
  id: string
  title: string
  artist: string
  genre: string
  fileUrl: string
}

export function SearchResults({ query }: { query: string }) {
  const [results, setResults] = useState<SearchResult[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    const fetchResults = async () => {
      if (!query.trim()) {
        setResults([])
        setIsLoading(false)
        return
      }

      try {
        // In a real app, fetch from your API
        // const response = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        // const data = await response.json();
        // setResults(data.results);

        // Mock search results for demonstration
        const mockResults: SearchResult[] = [
          {
            id: "1",
            title: "Africa Trap Beat",
            artist: "cupicsart",
            genre: "Trap",
            fileUrl: "https://example.com/audio1.mp3",
          },
          {
            id: "2",
            title: "Story Telling Type Beat",
            artist: "Cupicsart",
            genre: "Hip Hop",
            fileUrl: "https://example.com/audio2.mp3",
          },
        ].filter(
          (item) =>
            item.title.toLowerCase().includes(query.toLowerCase()) ||
            item.artist.toLowerCase().includes(query.toLowerCase()) ||
            item.genre.toLowerCase().includes(query.toLowerCase()),
        )

        setResults(mockResults)
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to fetch search results. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchResults()
  }, [query, toast])

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <p>Searching...</p>
      </div>
    )
  }

  if (results.length === 0) {
    return (
      <div className="text-center py-8">
        <p>No results found for "{query}". Try a different search term.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {results.map((result) => (
        <Card key={result.id} className="overflow-hidden">
          <div className="flex items-center p-4">
            <Button variant="ghost" size="icon" className="mr-4" aria-label="Play">
              <Play className="h-6 w-6" />
            </Button>

            <div>
              <h3 className="text-lg font-semibold">{result.title}</h3>
              <p className="text-sm text-gray-500">
                {result.artist} • {result.genre}
              </p>
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
