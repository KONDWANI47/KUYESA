import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { GenresGrid } from "@/components/genres-grid"

export default function GenresPage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <section className="flex-1 container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">Explore Genres</h1>
        <GenresGrid />
      </section>
      <Footer />
    </main>
  )
}
