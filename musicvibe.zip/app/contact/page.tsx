import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { ContactForm } from "@/components/contact-form"

export default function ContactPage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <section className="flex-1 container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">Contact Us</h1>
        <ContactForm />
      </section>
      <Footer />
    </main>
  )
}
