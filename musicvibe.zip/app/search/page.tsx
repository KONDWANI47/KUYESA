import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { SearchResults } from "@/components/search-results"

export default function SearchPage({
  searchParams,
}: {
  searchParams: { q: string }
}) {
  const query = searchParams.q || ""

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <section className="flex-1 container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">Search Results for "{query}"</h1>
        <SearchResults query={query} />
      </section>
      <Footer />
    </main>
  )
}
