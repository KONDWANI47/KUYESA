import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { PlaylistsSection } from "@/components/playlists-section"

export default function PlaylistsPage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <section className="flex-1 container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">Playlists</h1>
        <PlaylistsSection />
      </section>
      <Footer />
    </main>
  )
}
