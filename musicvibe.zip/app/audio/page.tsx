import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { AudioUploadForm } from "@/components/audio-upload-form"
import { AudioList } from "@/components/audio-list"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { redirect } from "next/navigation"

export default async function AudioPage() {
  const session = await getServerSession(authOptions)

  if (!session) {
    redirect("/")
  }

  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <section className="flex-1 container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">Audio</h1>
        <AudioUploadForm />
        <AudioList />
      </section>
      <Footer />
    </main>
  )
}
