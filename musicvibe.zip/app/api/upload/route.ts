import { db } from "@/lib/db"
import { getServerSession } from "next-auth"
import { NextResponse } from "next/server"
import { authOptions } from "@/lib/auth"
import { z } from "zod"

const audioSchema = z.object({
  title: z.string().min(3).max(100),
  artist: z.string().min(2).max(100),
  genre: z.string().min(2).max(50),
  fileUrl: z.string().url(),
})

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await req.json()
    const { title, artist, genre, fileUrl } = audioSchema.parse(body)

    const audio = await db.audio.create({
      data: {
        title,
        artist,
        genre,
        fileUrl,
        userId: session.user.id,
      },
    })

    return NextResponse.json({ audio, message: "Audio uploaded successfully" }, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }

    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
