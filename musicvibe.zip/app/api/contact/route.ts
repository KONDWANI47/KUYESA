import { NextResponse } from "next/server"
import { z } from "zod"

const contactSchema = z.object({
  name: z.string().min(2).max(100),
  email: z.string().email(),
  message: z.string().min(10).max(1000),
})

export async function POST(req: Request) {
  try {
    const body = await req.json()
    const { name, email, message } = contactSchema.parse(body)

    // Here you would typically send an email or store the contact message
    // For now, we'll just return a success response

    console.log("Contact form submission:", { name, email, message })

    return NextResponse.json({ message: "Message sent successfully" }, { status: 200 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: error.errors }, { status: 400 })
    }

    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
