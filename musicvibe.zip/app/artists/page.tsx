import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { ArtistsGrid } from "@/components/artists-grid"

export default function ArtistsPage() {
  return (
    <main className="min-h-screen flex flex-col">
      <Navbar />
      <section className="flex-1 container mx-auto py-8 px-4">
        <h1 className="text-3xl font-bold mb-6">Featured Producers</h1>
        <ArtistsGrid />
      </section>
      <Footer />
    </main>
  )
}
